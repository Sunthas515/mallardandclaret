module.exports = {
    client: 'mysql',
    connection: {
        host: '110.232.143.7',
        database: 'mallarda_db',
        user: 'mallarda',
        password: 'ggm6gSnWwM'
    }
}